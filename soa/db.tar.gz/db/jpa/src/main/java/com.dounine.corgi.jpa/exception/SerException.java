package com.dounine.corgi.jpa.exception;

/**
 * Created by huanghuanlai on 16/6/13.
 */
public class SerException extends Throwable {

    public SerException() {
        super();
    }

    public SerException(String message) {
        super(message);
    }
}
