package corgi.spring.test_java_service.code.dto;

import com.dounine.corgi.jpa.dto.BaseDto;

/**
 * Created by lgq on 16-10-13.
 */
public class UserDto extends BaseDto {
}
