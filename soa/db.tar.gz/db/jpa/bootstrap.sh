#!/bin/bash
gradle clean build -x test
